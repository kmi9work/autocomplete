# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Autoc::Application.config.secret_token = 'b69d9d3735a5573dca5d9e21cfa4f324087934c39943f59ab8d724c9f02e2f5f929a00e2cee5fc6231d1be3496b0c3d59225a0df44b1af9042bb6850551a7224'
