class Cases < ActiveRecord::Base
end
